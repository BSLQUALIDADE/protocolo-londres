#!/bin/bash
# ============================================================
# Script de instalação da correção de sincronização com Supabase
# (Opção B: loadStageData/saveStageData passam a sincronizar com a API)
# ============================================================
set -e

echo "🏥 Protocolo de Londres — Instalando correção de sincronização"
echo ""

if [ ! -f "server.js" ]; then
    echo "❌ Não encontrei server.js na pasta atual."
    echo "   Rode este script dentro de ~/protocolo-londres"
    exit 1
fi

# Cria backup com timestamp
BACKUP_DIR="backup-pre-sync-$(date +%Y%m%d-%H%M%S)"
mkdir -p "$BACKUP_DIR"

echo "📦 Fazendo backup dos arquivos atuais em $BACKUP_DIR/ ..."
cp shared-components.js "$BACKUP_DIR/" 2>/dev/null || true
cp novo-protocolo.html "$BACKUP_DIR/" 2>/dev/null || true
for i in $(seq 1 17); do
    cp "etapa-$i.html" "$BACKUP_DIR/" 2>/dev/null || true
done
echo "✅ Backup concluído"
echo ""

# Extrai o pacote novo (assume que protocolo-londres-sync-fix.zip está na pasta atual)
if [ ! -f "protocolo-londres-sync-fix.zip" ]; then
    echo "❌ Não encontrei protocolo-londres-sync-fix.zip na pasta atual."
    echo "   Baixe o arquivo e coloque em ~/protocolo-londres antes de rodar este script."
    exit 1
fi

echo "📂 Extraindo arquivos corrigidos..."
unzip -o protocolo-londres-sync-fix.zip -d . > /dev/null
echo "✅ Arquivos extraídos e substituídos"
echo ""

echo "🔍 Validando sintaxe de todos os arquivos..."
node -e "
const fs = require('fs');
const code = fs.readFileSync('shared-components.js', 'utf-8');
try {
    new Function(code);
    console.log('✅ shared-components.js: sintaxe OK');
} catch(e) {
    console.log('❌ shared-components.js: ERRO -', e.message);
    process.exit(1);
}
"

for i in $(seq 1 17); do
    node -e "
const fs = require('fs');
const re = /<script(?![^>]*\bsrc=)[^>]*>([\s\S]*?)<\/script>/g;
const content = fs.readFileSync('etapa-$i.html', 'utf-8');
let match;
let blocos = [];
while ((match = re.exec(content)) !== null) {
    blocos.push(match[1]);
}
const code = blocos.join('\n;\n');
try {
    new Function(code);
    console.log('✅ etapa-$i.html: sintaxe OK');
} catch(e) {
    console.log('❌ etapa-$i.html: ERRO -', e.message);
    process.exit(1);
}
"
done

echo ""
echo "🎉 Instalação concluída com sucesso!"
echo ""
echo "👉 Próximos passos:"
echo "   1. Reinicie o servidor: pkill -f 'node server.js'; node server.js &"
echo "   2. Abra o navegador em http://localhost:3000/novo-protocolo.html"
echo "   3. O painel de progresso deve agora mostrar as etapas preenchidas via API/script"
echo "   4. Vá até a Etapa 17 e gere o relatório normalmente"
echo ""
echo "Se algo der errado, os arquivos originais estão em: $BACKUP_DIR/"
